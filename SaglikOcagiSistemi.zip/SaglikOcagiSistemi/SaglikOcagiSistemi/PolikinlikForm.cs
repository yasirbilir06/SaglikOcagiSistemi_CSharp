﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace SaglikOcagiSistemi
{
    public partial class PoliklinikForm : Form
    {
        public PoliklinikForm()
        {
            InitializeComponent();
        }

        private void PoliklinikForm_Load(object sender, EventArgs e)
        {
            LoadPoliklinikAdi();
        }

        private void LoadPoliklinikAdi()
        {
            string connectionString = "Server=FURKAN\\SQLEXPRESS;Database=SaglikOcagi;Trusted_Connection=True;";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT poliklinikAdi FROM Poliklinik";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            cmbPoliklinikAdi.Items.Clear();
                            while (reader.Read())
                            {
                                cmbPoliklinikAdi.Items.Add(reader["poliklinikAdi"].ToString());
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnGuncelle_Click(object sender, EventArgs e)
        {
            string poliklinikAdi = cmbPoliklinikAdi.Text.Trim();
            bool durum = chkGecerliGecersiz.Checked;

            if (string.IsNullOrEmpty(poliklinikAdi))
            {
                MessageBox.Show("Poliklinik adı boş bırakılamaz!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string connectionString = "Server=FURKAN\\SQLEXPRESS;Database=SaglikOcagi;Trusted_Connection=True;";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "UPDATE Poliklinik SET durum = @Durum WHERE poliklinikAdi = @PoliklinikAdi";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@PoliklinikAdi", poliklinikAdi);
                        cmd.Parameters.AddWithValue("@Durum", durum ? "Aktif" : "Pasif");

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Poliklinik başarıyla güncellendi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnSil_Click(object sender, EventArgs e)
        {
            string poliklinikAdi = cmbPoliklinikAdi.Text.Trim();

            if (string.IsNullOrEmpty(poliklinikAdi))
            {
                MessageBox.Show("Silmek istediğiniz poliklinik adını seçiniz!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string connectionString = "Server=FURKAN\\SQLEXPRESS;Database=SaglikOcagi;Trusted_Connection=True;";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "DELETE FROM Poliklinik WHERE poliklinikAdi = @PoliklinikAdi";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@PoliklinikAdi", poliklinikAdi);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Poliklinik başarıyla silindi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        cmbPoliklinikAdi.Items.Remove(poliklinikAdi);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnCikis_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmbPoliklinikAdi_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedPoliklinik = cmbPoliklinikAdi.SelectedItem.ToString();

            string connectionString = "Server=FURKAN\\SQLEXPRESS;Database=SaglikOcagi;Trusted_Connection=True;";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT durum, aciklama FROM Poliklinik WHERE poliklinikAdi = @PoliklinikAdi";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@PoliklinikAdi", selectedPoliklinik);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                chkGecerliGecersiz.Checked = reader["durum"].ToString() == "Aktif";
                                txtAciklama.Text = reader["aciklama"].ToString();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}