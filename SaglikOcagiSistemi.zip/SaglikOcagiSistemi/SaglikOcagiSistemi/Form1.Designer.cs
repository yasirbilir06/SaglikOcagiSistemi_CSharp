﻿namespace SaglikOcagiSistemi
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvHastaListesi = new System.Windows.Forms.DataGridView();
            this.dtpBaslangic = new System.Windows.Forms.DateTimePicker();
            this.dtpBitis = new System.Windows.Forms.DateTimePicker();
            this.rbTaburcuOlmus = new System.Windows.Forms.RadioButton();
            this.rbTaburcuOlmamis = new System.Windows.Forms.RadioButton();
            this.rbHepsi = new System.Windows.Forms.RadioButton();
            this.btnSorgula = new System.Windows.Forms.Button();
            this.btnTemizle = new System.Windows.Forms.Button();
            this.btnYazdir = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHastaListesi)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvHastaListesi
            // 
            this.dgvHastaListesi.Location = new System.Drawing.Point(20, 100);
            this.dgvHastaListesi.Name = "dgvHastaListesi";
            this.dgvHastaListesi.Size = new System.Drawing.Size(600, 200);
            this.dgvHastaListesi.TabIndex = 5;
            // 
            // dtpBaslangic
            // 
            this.dtpBaslangic.Location = new System.Drawing.Point(20, 20);
            this.dtpBaslangic.Name = "dtpBaslangic";
            this.dtpBaslangic.Size = new System.Drawing.Size(200, 22);
            this.dtpBaslangic.TabIndex = 0;
            // 
            // dtpBitis
            // 
            this.dtpBitis.Location = new System.Drawing.Point(250, 20);
            this.dtpBitis.Name = "dtpBitis";
            this.dtpBitis.Size = new System.Drawing.Size(200, 22);
            this.dtpBitis.TabIndex = 1;
            // 
            // rbTaburcuOlmus
            // 
            this.rbTaburcuOlmus.AutoSize = true;
            this.rbTaburcuOlmus.Location = new System.Drawing.Point(20, 60);
            this.rbTaburcuOlmus.Name = "rbTaburcuOlmus";
            this.rbTaburcuOlmus.Size = new System.Drawing.Size(114, 20);
            this.rbTaburcuOlmus.TabIndex = 2;
            this.rbTaburcuOlmus.Text = "Taburcu olmuş";
            this.rbTaburcuOlmus.UseVisualStyleBackColor = true;
            // 
            // rbTaburcuOlmamis
            // 
            this.rbTaburcuOlmamis.AutoSize = true;
            this.rbTaburcuOlmamis.Location = new System.Drawing.Point(140, 60);
            this.rbTaburcuOlmamis.Name = "rbTaburcuOlmamis";
            this.rbTaburcuOlmamis.Size = new System.Drawing.Size(129, 20);
            this.rbTaburcuOlmamis.TabIndex = 3;
            this.rbTaburcuOlmamis.Text = "Taburcu olmamış";
            this.rbTaburcuOlmamis.UseVisualStyleBackColor = true;
            // 
            // rbHepsi
            // 
            this.rbHepsi.AutoSize = true;
            this.rbHepsi.Checked = true;
            this.rbHepsi.Location = new System.Drawing.Point(279, 60);
            this.rbHepsi.Name = "rbHepsi";
            this.rbHepsi.Size = new System.Drawing.Size(61, 20);
            this.rbHepsi.TabIndex = 4;
            this.rbHepsi.TabStop = true;
            this.rbHepsi.Text = "Hepsi";
            this.rbHepsi.UseVisualStyleBackColor = true;
            // 
            // btnSorgula
            // 
            this.btnSorgula.Location = new System.Drawing.Point(20, 320);
            this.btnSorgula.Name = "btnSorgula";
            this.btnSorgula.Size = new System.Drawing.Size(75, 23);
            this.btnSorgula.TabIndex = 6;
            this.btnSorgula.Text = "Sorgula";
            this.btnSorgula.UseVisualStyleBackColor = true;
            this.btnSorgula.Click += new System.EventHandler(this.btnSorgula_Click);
            // 
            // btnTemizle
            // 
            this.btnTemizle.Location = new System.Drawing.Point(120, 320);
            this.btnTemizle.Name = "btnTemizle";
            this.btnTemizle.Size = new System.Drawing.Size(75, 23);
            this.btnTemizle.TabIndex = 7;
            this.btnTemizle.Text = "Temizle";
            this.btnTemizle.UseVisualStyleBackColor = true;
            this.btnTemizle.Click += new System.EventHandler(this.btnTemizle_Click);
            // 
            // btnYazdir
            // 
            this.btnYazdir.Location = new System.Drawing.Point(220, 320);
            this.btnYazdir.Name = "btnYazdir";
            this.btnYazdir.Size = new System.Drawing.Size(75, 23);
            this.btnYazdir.TabIndex = 8;
            this.btnYazdir.Text = "Yazdır";
            this.btnYazdir.UseVisualStyleBackColor = true;
            this.btnYazdir.Click += new System.EventHandler(this.btnYazdir_Click);
            // 
            // btnCikis
            // 
            this.btnCikis.Location = new System.Drawing.Point(320, 320);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(75, 23);
            this.btnCikis.TabIndex = 9;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = true;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // Form1
            // 
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(640, 360);
            this.Controls.Add(this.dtpBaslangic);
            this.Controls.Add(this.dtpBitis);
            this.Controls.Add(this.rbTaburcuOlmus);
            this.Controls.Add(this.rbTaburcuOlmamis);
            this.Controls.Add(this.rbHepsi);
            this.Controls.Add(this.dgvHastaListesi);
            this.Controls.Add(this.btnSorgula);
            this.Controls.Add(this.btnTemizle);
            this.Controls.Add(this.btnYazdir);
            this.Controls.Add(this.btnCikis);
            this.Name = "Form1";
            this.Text = "Hasta Listesi";
            ((System.ComponentModel.ISupportInitialize)(this.dgvHastaListesi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.DataGridView dgvHastaListesi;
        private System.Windows.Forms.DateTimePicker dtpBaslangic;
        private System.Windows.Forms.DateTimePicker dtpBitis;
        private System.Windows.Forms.RadioButton rbTaburcuOlmus;
        private System.Windows.Forms.RadioButton rbTaburcuOlmamis;
        private System.Windows.Forms.RadioButton rbHepsi;
        private System.Windows.Forms.Button btnSorgula;
        private System.Windows.Forms.Button btnTemizle;
        private System.Windows.Forms.Button btnYazdir;
        private System.Windows.Forms.Button btnCikis;
    }
}