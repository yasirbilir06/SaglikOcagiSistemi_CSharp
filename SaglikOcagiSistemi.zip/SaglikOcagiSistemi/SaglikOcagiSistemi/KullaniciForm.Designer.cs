﻿namespace SaglikOcagiSistemi
{
    partial class KullaniciForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblKullaniciKodu;
        private System.Windows.Forms.ComboBox cmbKullaniciKodu;
        private System.Windows.Forms.Button btnYeniKullaniciEkle;

        /// <summary>
        /// Dispose işlemi için gerekli temizlik.
        /// </summary>
        /// <param name="disposing">Yönetilen kaynakları atamak için true, aksi halde false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Tasarımı başlatır ve bileşenleri ekler.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblKullaniciKodu = new System.Windows.Forms.Label();
            this.cmbKullaniciKodu = new System.Windows.Forms.ComboBox();
            this.btnYeniKullaniciEkle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblKullaniciKodu
            // 
            this.lblKullaniciKodu.AutoSize = true;
            this.lblKullaniciKodu.Location = new System.Drawing.Point(27, 25);
            this.lblKullaniciKodu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblKullaniciKodu.Name = "lblKullaniciKodu";
            this.lblKullaniciKodu.Size = new System.Drawing.Size(93, 16);
            this.lblKullaniciKodu.TabIndex = 0;
            this.lblKullaniciKodu.Text = "Kullanıcı Kodu:";
            // 
            // cmbKullaniciKodu
            // 
            this.cmbKullaniciKodu.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.cmbKullaniciKodu.FormattingEnabled = true;
            this.cmbKullaniciKodu.Location = new System.Drawing.Point(160, 25);
            this.cmbKullaniciKodu.Margin = new System.Windows.Forms.Padding(4);
            this.cmbKullaniciKodu.Name = "cmbKullaniciKodu";
            this.cmbKullaniciKodu.Size = new System.Drawing.Size(265, 24);
            this.cmbKullaniciKodu.TabIndex = 1;
            this.cmbKullaniciKodu.SelectedIndexChanged += new System.EventHandler(this.cmbKullaniciKodu_SelectedIndexChanged);
            // 
            // btnYeniKullaniciEkle
            // 
            this.btnYeniKullaniciEkle.Location = new System.Drawing.Point(160, 74);
            this.btnYeniKullaniciEkle.Margin = new System.Windows.Forms.Padding(4);
            this.btnYeniKullaniciEkle.Name = "btnYeniKullaniciEkle";
            this.btnYeniKullaniciEkle.Size = new System.Drawing.Size(267, 28);
            this.btnYeniKullaniciEkle.TabIndex = 2;
            this.btnYeniKullaniciEkle.Text = "Yeni Kullanıcı Ekle";
            this.btnYeniKullaniciEkle.UseVisualStyleBackColor = true;
            
            // 
            // KullaniciForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(467, 148);
            this.Controls.Add(this.lblKullaniciKodu);
            this.Controls.Add(this.cmbKullaniciKodu);
            this.Controls.Add(this.btnYeniKullaniciEkle);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "KullaniciForm";
            this.Text = "Kullanıcı Tanıtma";
            this.Load += new System.EventHandler(this.KullaniciForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}