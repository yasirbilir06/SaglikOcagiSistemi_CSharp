﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace SaglikOcagiSistemi
{
    public partial class Form1 : Form
    {
        private SqlConnection conn = new SqlConnection("Server=.;Database=SaglikOcagi;Trusted_Connection=True;");

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSorgula_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT * FROM Hasta WHERE SevkTarihi BETWEEN @Baslangic AND @Bitis";

                if (rbTaburcuOlmus.Checked)
                    query += " AND Taburcu = 1";
                else if (rbTaburcuOlmamis.Checked)
                    query += " AND Taburcu = 0";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Baslangic", dtpBaslangic.Value);
                cmd.Parameters.AddWithValue("@Bitis", dtpBitis.Value);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable table = new DataTable();
                adapter.Fill(table);

                dgvHastaListesi.DataSource = table;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hata: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTemizle_Click(object sender, EventArgs e)
        {
            dgvHastaListesi.DataSource = null;
        }

        private void btnYazdir_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Yazdırma işlemi başlatıldı.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}