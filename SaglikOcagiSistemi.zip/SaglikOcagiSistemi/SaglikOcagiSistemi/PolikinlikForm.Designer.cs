﻿namespace SaglikOcagiSistemi
{
    partial class PoliklinikForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblPoliklinikAdi;
        private System.Windows.Forms.CheckBox chkGecerliGecersiz;
        private System.Windows.Forms.TextBox txtAciklama;
        private System.Windows.Forms.Button btnGuncelle;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.ComboBox cmbPoliklinikAdi;

        /// <summary>
        /// Dispose işlemi için gerekli temizlik.
        /// </summary>
        /// <param name="disposing">Yönetilen kaynakları atamak için true, aksi halde false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Tasarımı başlatır ve bileşenleri ekler.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPoliklinikAdi = new System.Windows.Forms.Label();
            this.chkGecerliGecersiz = new System.Windows.Forms.CheckBox();
            this.txtAciklama = new System.Windows.Forms.TextBox();
            this.btnGuncelle = new System.Windows.Forms.Button();
            this.btnSil = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.cmbPoliklinikAdi = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblPoliklinikAdi
            // 
            this.lblPoliklinikAdi.AutoSize = true;
            this.lblPoliklinikAdi.Location = new System.Drawing.Point(30, 20);
            this.lblPoliklinikAdi.Name = "lblPoliklinikAdi";
            this.lblPoliklinikAdi.Size = new System.Drawing.Size(86, 16);
            this.lblPoliklinikAdi.TabIndex = 0;
            this.lblPoliklinikAdi.Text = "Poliklinik Adı:";
            // 
            // chkGecerliGecersiz
            // 
            this.chkGecerliGecersiz.AutoSize = true;
            this.chkGecerliGecersiz.Location = new System.Drawing.Point(130, 60);
            this.chkGecerliGecersiz.Name = "chkGecerliGecersiz";
            this.chkGecerliGecersiz.Size = new System.Drawing.Size(132, 20);
            this.chkGecerliGecersiz.TabIndex = 2;
            this.chkGecerliGecersiz.Text = "Geçerli / Geçersiz";
            this.chkGecerliGecersiz.UseVisualStyleBackColor = true;
            // 
            // txtAciklama
            // 
            this.txtAciklama.Location = new System.Drawing.Point(30, 100);
            this.txtAciklama.Multiline = true;
            this.txtAciklama.Name = "txtAciklama";
            this.txtAciklama.Size = new System.Drawing.Size(350, 80);
            this.txtAciklama.TabIndex = 3;
            // 
            // btnGuncelle
            // 
            this.btnGuncelle.Location = new System.Drawing.Point(30, 200);
            this.btnGuncelle.Name = "btnGuncelle";
            this.btnGuncelle.Size = new System.Drawing.Size(100, 30);
            this.btnGuncelle.TabIndex = 4;
            this.btnGuncelle.Text = "Güncelle";
            this.btnGuncelle.UseVisualStyleBackColor = true;
            this.btnGuncelle.Click += new System.EventHandler(this.BtnGuncelle_Click);
            // 
            // btnSil
            // 
            this.btnSil.Location = new System.Drawing.Point(150, 200);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(100, 30);
            this.btnSil.TabIndex = 5;
            this.btnSil.Text = "Sil";
            this.btnSil.UseVisualStyleBackColor = true;
            this.btnSil.Click += new System.EventHandler(this.BtnSil_Click);
            // 
            // btnCikis
            // 
            this.btnCikis.Location = new System.Drawing.Point(280, 200);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(100, 30);
            this.btnCikis.TabIndex = 6;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = true;
            this.btnCikis.Click += new System.EventHandler(this.BtnCikis_Click);
            // 
            // cmbPoliklinikAdi
            // 
            this.cmbPoliklinikAdi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPoliklinikAdi.FormattingEnabled = true;
            this.cmbPoliklinikAdi.Location = new System.Drawing.Point(130, 17);
            this.cmbPoliklinikAdi.Name = "cmbPoliklinikAdi";
            this.cmbPoliklinikAdi.Size = new System.Drawing.Size(250, 24);
            this.cmbPoliklinikAdi.TabIndex = 1;
            this.cmbPoliklinikAdi.SelectedIndexChanged += new System.EventHandler(this.cmbPoliklinikAdi_SelectedIndexChanged);
            // 
            // PoliklinikForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(420, 250);
            this.Controls.Add(this.btnCikis);
            this.Controls.Add(this.btnSil);
            this.Controls.Add(this.btnGuncelle);
            this.Controls.Add(this.txtAciklama);
            this.Controls.Add(this.chkGecerliGecersiz);
            this.Controls.Add(this.cmbPoliklinikAdi);
            this.Controls.Add(this.lblPoliklinikAdi);
            this.Name = "PoliklinikForm";
            this.Text = "Poliklinik Tanıtma";
            this.Load += new System.EventHandler(this.PoliklinikForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}