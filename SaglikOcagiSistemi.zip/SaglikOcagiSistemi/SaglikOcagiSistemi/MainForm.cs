﻿using System;
using System.Windows.Forms;

namespace SaglikOcagiSistemi
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
        }

        private void poliklinikTanıtmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Poliklinik Tanıtma Formu Açılacak.");
        }

        private void kullanıcıTanıtmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Kullanıcı Tanıtma Formu Açılacak.");
        }

        private void çıkışToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Gerekli başlangıç ayarları burada yapılabilir
            MessageBox.Show("Hoş geldiniz!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void hastaIslemleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void cikisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MainForm_Load_1(object sender, EventArgs e)
        {
            // Main form yüklendiğinde yapılması gereken işlemler
            // Örneğin:
            MessageBox.Show("Main form başarıyla yüklendi!");
        }

        private void polikinlikTanıtmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PoliklinikForm poliklinikForm = new PoliklinikForm();
            poliklinikForm.ShowDialog();
        }

        private void kullanıcıTanıtmaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            try
            {
                KullaniciForm kullaniciForm = new KullaniciForm();
                kullaniciForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hata: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void hastaIslemleriToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            try
            {
                // Hasta İşlemleri Formunu oluştur ve aç
                HastaIslemleriForm hastaIslemleriForm = new HastaIslemleriForm();
                hastaIslemleriForm.ShowDialog(); // Modal olarak açar
            }
            catch (Exception ex)
            {
                // Hata durumunda kullanıcıya bilgi ver
                MessageBox.Show($"Hasta İşlemleri formu açılırken bir hata oluştu: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}