﻿namespace SaglikOcagiSistemi
{
    partial class KullaniciTanıtmaForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblKullaniciKodu = new System.Windows.Forms.Label();
            this.txtKullaniciKodu = new System.Windows.Forms.TextBox();
            this.lblTCNo = new System.Windows.Forms.Label();
            this.txtTCNo = new System.Windows.Forms.TextBox();
            this.lblDogumYeri = new System.Windows.Forms.Label();
            this.txtDogumYeri = new System.Windows.Forms.TextBox();
            this.lblBabaAdi = new System.Windows.Forms.Label();
            this.txtBabaAdi = new System.Windows.Forms.TextBox();
            this.lblAnneAdi = new System.Windows.Forms.Label();
            this.txtAnneAdi = new System.Windows.Forms.TextBox();
            this.lblTelefonNo = new System.Windows.Forms.Label();
            this.txtTelefonNo = new System.Windows.Forms.TextBox();
            this.lblGSM = new System.Windows.Forms.Label();
            this.txtGSM = new System.Windows.Forms.TextBox();
            this.chkYetkili = new System.Windows.Forms.CheckBox();
            this.lblAdres = new System.Windows.Forms.Label();
            this.rtbAdres = new System.Windows.Forms.RichTextBox();
            this.lblKullaniciAdi = new System.Windows.Forms.Label();
            this.txtKullaniciAdi = new System.Windows.Forms.TextBox();
            this.lblSifre = new System.Windows.Forms.Label();
            this.txtSifre = new System.Windows.Forms.TextBox();
            this.lblUnvan = new System.Windows.Forms.Label();
            this.cbUnvan = new System.Windows.Forms.ComboBox();
            this.lblAd = new System.Windows.Forms.Label();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.lblSoyad = new System.Windows.Forms.Label();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.lblMaas = new System.Windows.Forms.Label();
            this.txtMaas = new System.Windows.Forms.TextBox();
            this.lblIseBaslama = new System.Windows.Forms.Label();
            this.dtpIseBaslama = new System.Windows.Forms.DateTimePicker();
            this.lblDogumTarihi = new System.Windows.Forms.Label();
            this.dtpDogumTarihi = new System.Windows.Forms.DateTimePicker();
            this.lblCinsiyet = new System.Windows.Forms.Label();
            this.cbCinsiyet = new System.Windows.Forms.ComboBox();
            this.lblKanGrubu = new System.Windows.Forms.Label();
            this.cbKanGrubu = new System.Windows.Forms.ComboBox();
            this.btnTemizle = new System.Windows.Forms.Button();
            this.btnGuncelle = new System.Windows.Forms.Button();
            this.btnSil = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblKullaniciKodu
            // 
            this.lblKullaniciKodu.Location = new System.Drawing.Point(20, 20);
            this.lblKullaniciKodu.Name = "lblKullaniciKodu";
            this.lblKullaniciKodu.Size = new System.Drawing.Size(100, 23);
            this.lblKullaniciKodu.TabIndex = 0;
            this.lblKullaniciKodu.Text = "Kullanıcı Kodu";
            // 
            // txtKullaniciKodu
            // 
            this.txtKullaniciKodu.Location = new System.Drawing.Point(120, 20);
            this.txtKullaniciKodu.Name = "txtKullaniciKodu";
            this.txtKullaniciKodu.Size = new System.Drawing.Size(150, 22);
            this.txtKullaniciKodu.TabIndex = 1;
            // 
            // lblTCNo
            // 
            this.lblTCNo.Location = new System.Drawing.Point(20, 60);
            this.lblTCNo.Name = "lblTCNo";
            this.lblTCNo.Size = new System.Drawing.Size(100, 23);
            this.lblTCNo.TabIndex = 2;
            this.lblTCNo.Text = "T.C. Kimlik Numarası";
            // 
            // txtTCNo
            // 
            this.txtTCNo.Location = new System.Drawing.Point(120, 60);
            this.txtTCNo.Name = "txtTCNo";
            this.txtTCNo.Size = new System.Drawing.Size(150, 22);
            this.txtTCNo.TabIndex = 3;
            // 
            // lblDogumYeri
            // 
            this.lblDogumYeri.Location = new System.Drawing.Point(20, 100);
            this.lblDogumYeri.Name = "lblDogumYeri";
            this.lblDogumYeri.Size = new System.Drawing.Size(100, 23);
            this.lblDogumYeri.TabIndex = 4;
            this.lblDogumYeri.Text = "Doğum Yeri";
            // 
            // txtDogumYeri
            // 
            this.txtDogumYeri.Location = new System.Drawing.Point(120, 100);
            this.txtDogumYeri.Name = "txtDogumYeri";
            this.txtDogumYeri.Size = new System.Drawing.Size(150, 22);
            this.txtDogumYeri.TabIndex = 5;
            // 
            // lblBabaAdi
            // 
            this.lblBabaAdi.Location = new System.Drawing.Point(20, 140);
            this.lblBabaAdi.Name = "lblBabaAdi";
            this.lblBabaAdi.Size = new System.Drawing.Size(100, 23);
            this.lblBabaAdi.TabIndex = 6;
            this.lblBabaAdi.Text = "Baba Adı";
            // 
            // txtBabaAdi
            // 
            this.txtBabaAdi.Location = new System.Drawing.Point(120, 140);
            this.txtBabaAdi.Name = "txtBabaAdi";
            this.txtBabaAdi.Size = new System.Drawing.Size(150, 22);
            this.txtBabaAdi.TabIndex = 7;
            // 
            // lblAnneAdi
            // 
            this.lblAnneAdi.Location = new System.Drawing.Point(20, 180);
            this.lblAnneAdi.Name = "lblAnneAdi";
            this.lblAnneAdi.Size = new System.Drawing.Size(100, 23);
            this.lblAnneAdi.TabIndex = 8;
            this.lblAnneAdi.Text = "Anne Adı";
            // 
            // txtAnneAdi
            // 
            this.txtAnneAdi.Location = new System.Drawing.Point(120, 180);
            this.txtAnneAdi.Name = "txtAnneAdi";
            this.txtAnneAdi.Size = new System.Drawing.Size(150, 22);
            this.txtAnneAdi.TabIndex = 9;
            // 
            // lblTelefonNo
            // 
            this.lblTelefonNo.Location = new System.Drawing.Point(20, 220);
            this.lblTelefonNo.Name = "lblTelefonNo";
            this.lblTelefonNo.Size = new System.Drawing.Size(100, 23);
            this.lblTelefonNo.TabIndex = 10;
            this.lblTelefonNo.Text = "Telefon No";
            // 
            // txtTelefonNo
            // 
            this.txtTelefonNo.Location = new System.Drawing.Point(120, 220);
            this.txtTelefonNo.Name = "txtTelefonNo";
            this.txtTelefonNo.Size = new System.Drawing.Size(150, 22);
            this.txtTelefonNo.TabIndex = 11;
            // 
            // lblGSM
            // 
            this.lblGSM.Location = new System.Drawing.Point(20, 260);
            this.lblGSM.Name = "lblGSM";
            this.lblGSM.Size = new System.Drawing.Size(100, 23);
            this.lblGSM.TabIndex = 12;
            this.lblGSM.Text = "GSM";
            // 
            // txtGSM
            // 
            this.txtGSM.Location = new System.Drawing.Point(120, 260);
            this.txtGSM.Name = "txtGSM";
            this.txtGSM.Size = new System.Drawing.Size(150, 22);
            this.txtGSM.TabIndex = 13;
            // 
            // chkYetkili
            // 
            this.chkYetkili.Location = new System.Drawing.Point(20, 300);
            this.chkYetkili.Name = "chkYetkili";
            this.chkYetkili.Size = new System.Drawing.Size(104, 24);
            this.chkYetkili.TabIndex = 14;
            this.chkYetkili.Text = "Yetkili Kullanıcı";
            // 
            // lblAdres
            // 
            this.lblAdres.Location = new System.Drawing.Point(20, 340);
            this.lblAdres.Name = "lblAdres";
            this.lblAdres.Size = new System.Drawing.Size(100, 23);
            this.lblAdres.TabIndex = 15;
            this.lblAdres.Text = "Adres";
            // 
            // rtbAdres
            // 
            this.rtbAdres.Location = new System.Drawing.Point(120, 340);
            this.rtbAdres.Name = "rtbAdres";
            this.rtbAdres.Size = new System.Drawing.Size(400, 100);
            this.rtbAdres.TabIndex = 16;
            this.rtbAdres.Text = "";
            // 
            // lblKullaniciAdi
            // 
            this.lblKullaniciAdi.Location = new System.Drawing.Point(20, 460);
            this.lblKullaniciAdi.Name = "lblKullaniciAdi";
            this.lblKullaniciAdi.Size = new System.Drawing.Size(100, 23);
            this.lblKullaniciAdi.TabIndex = 17;
            this.lblKullaniciAdi.Text = "Kullanıcı Adı";
            // 
            // txtKullaniciAdi
            // 
            this.txtKullaniciAdi.Location = new System.Drawing.Point(120, 460);
            this.txtKullaniciAdi.Name = "txtKullaniciAdi";
            this.txtKullaniciAdi.Size = new System.Drawing.Size(150, 22);
            this.txtKullaniciAdi.TabIndex = 18;
            // 
            // lblSifre
            // 
            this.lblSifre.Location = new System.Drawing.Point(300, 460);
            this.lblSifre.Name = "lblSifre";
            this.lblSifre.Size = new System.Drawing.Size(100, 23);
            this.lblSifre.TabIndex = 19;
            this.lblSifre.Text = "Şifre";
            // 
            // txtSifre
            // 
            this.txtSifre.Location = new System.Drawing.Point(350, 460);
            this.txtSifre.Name = "txtSifre";
            this.txtSifre.Size = new System.Drawing.Size(150, 22);
            this.txtSifre.TabIndex = 20;
            // 
            // lblUnvan
            // 
            this.lblUnvan.Location = new System.Drawing.Point(300, 20);
            this.lblUnvan.Name = "lblUnvan";
            this.lblUnvan.Size = new System.Drawing.Size(100, 23);
            this.lblUnvan.TabIndex = 21;
            this.lblUnvan.Text = "Unvan";
            // 
            // cbUnvan
            // 
            this.cbUnvan.Location = new System.Drawing.Point(380, 20);
            this.cbUnvan.Name = "cbUnvan";
            this.cbUnvan.Size = new System.Drawing.Size(150, 24);
            this.cbUnvan.TabIndex = 22;
            // 
            // lblAd
            // 
            this.lblAd.Location = new System.Drawing.Point(300, 60);
            this.lblAd.Name = "lblAd";
            this.lblAd.Size = new System.Drawing.Size(100, 23);
            this.lblAd.TabIndex = 23;
            this.lblAd.Text = "Ad";
            // 
            // txtAd
            // 
            this.txtAd.Location = new System.Drawing.Point(380, 60);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(150, 22);
            this.txtAd.TabIndex = 24;
            // 
            // lblSoyad
            // 
            this.lblSoyad.Location = new System.Drawing.Point(300, 100);
            this.lblSoyad.Name = "lblSoyad";
            this.lblSoyad.Size = new System.Drawing.Size(100, 23);
            this.lblSoyad.TabIndex = 25;
            this.lblSoyad.Text = "Soyad";
            // 
            // txtSoyad
            // 
            this.txtSoyad.Location = new System.Drawing.Point(380, 100);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(150, 22);
            this.txtSoyad.TabIndex = 26;
            // 
            // lblMaas
            // 
            this.lblMaas.Location = new System.Drawing.Point(300, 140);
            this.lblMaas.Name = "lblMaas";
            this.lblMaas.Size = new System.Drawing.Size(100, 23);
            this.lblMaas.TabIndex = 27;
            this.lblMaas.Text = "Maaş";
            // 
            // txtMaas
            // 
            this.txtMaas.Location = new System.Drawing.Point(380, 140);
            this.txtMaas.Name = "txtMaas";
            this.txtMaas.Size = new System.Drawing.Size(150, 22);
            this.txtMaas.TabIndex = 28;
            // 
            // lblIseBaslama
            // 
            this.lblIseBaslama.Location = new System.Drawing.Point(300, 180);
            this.lblIseBaslama.Name = "lblIseBaslama";
            this.lblIseBaslama.Size = new System.Drawing.Size(100, 23);
            this.lblIseBaslama.TabIndex = 29;
            this.lblIseBaslama.Text = "İşe Başlama";
            // 
            // dtpIseBaslama
            // 
            this.dtpIseBaslama.Location = new System.Drawing.Point(380, 180);
            this.dtpIseBaslama.Name = "dtpIseBaslama";
            this.dtpIseBaslama.Size = new System.Drawing.Size(200, 22);
            this.dtpIseBaslama.TabIndex = 30;
            // 
            // lblDogumTarihi
            // 
            this.lblDogumTarihi.Location = new System.Drawing.Point(300, 220);
            this.lblDogumTarihi.Name = "lblDogumTarihi";
            this.lblDogumTarihi.Size = new System.Drawing.Size(100, 23);
            this.lblDogumTarihi.TabIndex = 31;
            this.lblDogumTarihi.Text = "Doğum Tarihi";
            // 
            // dtpDogumTarihi
            // 
            this.dtpDogumTarihi.Location = new System.Drawing.Point(380, 220);
            this.dtpDogumTarihi.Name = "dtpDogumTarihi";
            this.dtpDogumTarihi.Size = new System.Drawing.Size(200, 22);
            this.dtpDogumTarihi.TabIndex = 32;
            // 
            // lblCinsiyet
            // 
            this.lblCinsiyet.Location = new System.Drawing.Point(300, 260);
            this.lblCinsiyet.Name = "lblCinsiyet";
            this.lblCinsiyet.Size = new System.Drawing.Size(100, 23);
            this.lblCinsiyet.TabIndex = 33;
            this.lblCinsiyet.Text = "Cinsiyet";
            // 
            // cbCinsiyet
            // 
            this.cbCinsiyet.Location = new System.Drawing.Point(380, 260);
            this.cbCinsiyet.Name = "cbCinsiyet";
            this.cbCinsiyet.Size = new System.Drawing.Size(150, 24);
            this.cbCinsiyet.TabIndex = 34;
            // 
            // lblKanGrubu
            // 
            this.lblKanGrubu.Location = new System.Drawing.Point(300, 300);
            this.lblKanGrubu.Name = "lblKanGrubu";
            this.lblKanGrubu.Size = new System.Drawing.Size(100, 23);
            this.lblKanGrubu.TabIndex = 35;
            this.lblKanGrubu.Text = "Kan Grubu";
            // 
            // cbKanGrubu
            // 
            this.cbKanGrubu.Location = new System.Drawing.Point(380, 300);
            this.cbKanGrubu.Name = "cbKanGrubu";
            this.cbKanGrubu.Size = new System.Drawing.Size(150, 24);
            this.cbKanGrubu.TabIndex = 36;
            // 
            // btnTemizle
            // 
            this.btnTemizle.Location = new System.Drawing.Point(20, 500);
            this.btnTemizle.Name = "btnTemizle";
            this.btnTemizle.Size = new System.Drawing.Size(75, 23);
            this.btnTemizle.TabIndex = 37;
            this.btnTemizle.Text = "Temizle";
            // 
            // btnGuncelle
            // 
            this.btnGuncelle.Location = new System.Drawing.Point(120, 500);
            this.btnGuncelle.Name = "btnGuncelle";
            this.btnGuncelle.Size = new System.Drawing.Size(75, 23);
            this.btnGuncelle.TabIndex = 38;
            this.btnGuncelle.Text = "Güncelle";
            // 
            // btnSil
            // 
            this.btnSil.Location = new System.Drawing.Point(220, 500);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(75, 23);
            this.btnSil.TabIndex = 39;
            this.btnSil.Text = "Sil";
            // 
            // btnCikis
            // 
            this.btnCikis.Location = new System.Drawing.Point(320, 500);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(75, 23);
            this.btnCikis.TabIndex = 40;
            this.btnCikis.Text = "Çıkış";
            // 
            // KullaniciTanıtmaForm
            // 
            this.ClientSize = new System.Drawing.Size(600, 600);
            this.Controls.Add(this.lblKullaniciKodu);
            this.Controls.Add(this.txtKullaniciKodu);
            this.Controls.Add(this.lblTCNo);
            this.Controls.Add(this.txtTCNo);
            this.Controls.Add(this.lblDogumYeri);
            this.Controls.Add(this.txtDogumYeri);
            this.Controls.Add(this.lblBabaAdi);
            this.Controls.Add(this.txtBabaAdi);
            this.Controls.Add(this.lblAnneAdi);
            this.Controls.Add(this.txtAnneAdi);
            this.Controls.Add(this.lblTelefonNo);
            this.Controls.Add(this.txtTelefonNo);
            this.Controls.Add(this.lblGSM);
            this.Controls.Add(this.txtGSM);
            this.Controls.Add(this.chkYetkili);
            this.Controls.Add(this.lblAdres);
            this.Controls.Add(this.rtbAdres);
            this.Controls.Add(this.lblKullaniciAdi);
            this.Controls.Add(this.txtKullaniciAdi);
            this.Controls.Add(this.lblSifre);
            this.Controls.Add(this.txtSifre);
            this.Controls.Add(this.lblUnvan);
            this.Controls.Add(this.cbUnvan);
            this.Controls.Add(this.lblAd);
            this.Controls.Add(this.txtAd);
            this.Controls.Add(this.lblSoyad);
            this.Controls.Add(this.txtSoyad);
            this.Controls.Add(this.lblMaas);
            this.Controls.Add(this.txtMaas);
            this.Controls.Add(this.lblIseBaslama);
            this.Controls.Add(this.dtpIseBaslama);
            this.Controls.Add(this.lblDogumTarihi);
            this.Controls.Add(this.dtpDogumTarihi);
            this.Controls.Add(this.lblCinsiyet);
            this.Controls.Add(this.cbCinsiyet);
            this.Controls.Add(this.lblKanGrubu);
            this.Controls.Add(this.cbKanGrubu);
            this.Controls.Add(this.btnTemizle);
            this.Controls.Add(this.btnGuncelle);
            this.Controls.Add(this.btnSil);
            this.Controls.Add(this.btnCikis);
            this.Name = "KullaniciTanıtmaForm";
            this.Text = "Kullanıcı Tanıtma";
            this.Load += new System.EventHandler(this.KullaniciTanıtmaForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label lblKullaniciKodu;
        private System.Windows.Forms.TextBox txtKullaniciKodu;
        private System.Windows.Forms.Label lblTCNo;
        private System.Windows.Forms.TextBox txtTCNo;
        private System.Windows.Forms.Label lblDogumYeri;
        private System.Windows.Forms.TextBox txtDogumYeri;
        private System.Windows.Forms.Label lblBabaAdi;
        private System.Windows.Forms.TextBox txtBabaAdi;
        private System.Windows.Forms.Label lblAnneAdi;
        private System.Windows.Forms.TextBox txtAnneAdi;
        private System.Windows.Forms.Label lblTelefonNo;
        private System.Windows.Forms.TextBox txtTelefonNo;
        private System.Windows.Forms.Label lblGSM;
        private System.Windows.Forms.TextBox txtGSM;
        private System.Windows.Forms.CheckBox chkYetkili;
        private System.Windows.Forms.Label lblAdres;
        private System.Windows.Forms.RichTextBox rtbAdres;
        private System.Windows.Forms.Label lblKullaniciAdi;
        private System.Windows.Forms.TextBox txtKullaniciAdi;
        private System.Windows.Forms.Label lblSifre;
        private System.Windows.Forms.TextBox txtSifre;
        private System.Windows.Forms.Label lblUnvan;
        private System.Windows.Forms.ComboBox cbUnvan;
        private System.Windows.Forms.Label lblAd;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.Label lblSoyad;
        private System.Windows.Forms.TextBox txtSoyad;
        private System.Windows.Forms.Label lblMaas;
        private System.Windows.Forms.TextBox txtMaas;
        private System.Windows.Forms.Label lblIseBaslama;
        private System.Windows.Forms.DateTimePicker dtpIseBaslama;
        private System.Windows.Forms.Label lblDogumTarihi;
        private System.Windows.Forms.DateTimePicker dtpDogumTarihi;
        private System.Windows.Forms.Label lblCinsiyet;
        private System.Windows.Forms.ComboBox cbCinsiyet;
        private System.Windows.Forms.Label lblKanGrubu;
        private System.Windows.Forms.ComboBox cbKanGrubu;
        private System.Windows.Forms.Button btnTemizle;
        private System.Windows.Forms.Button btnGuncelle;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.Button btnCikis;
    }
}