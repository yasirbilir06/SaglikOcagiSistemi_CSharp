﻿namespace SaglikOcagiSistemi
{
    partial class HastaIslemleriForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblDosyaNo = new System.Windows.Forms.Label();
            this.txtDosyaNo = new System.Windows.Forms.TextBox();
            this.btnBul = new System.Windows.Forms.Button();
            this.lblSevkTarihi = new System.Windows.Forms.Label();
            this.dtpSevkTarihi = new System.Windows.Forms.DateTimePicker();
            this.lblHastaAdi = new System.Windows.Forms.Label();
            this.txtHastaAdi = new System.Windows.Forms.TextBox();
            this.lblSoyadi = new System.Windows.Forms.Label();
            this.txtSoyadi = new System.Windows.Forms.TextBox();
            this.lblKurumAdi = new System.Windows.Forms.Label();
            this.txtKurumAdi = new System.Windows.Forms.TextBox();
            this.btnHastaBilgileri = new System.Windows.Forms.Button();
            this.cbPoliklinik = new System.Windows.Forms.ComboBox();
            this.txtSiraNo = new System.Windows.Forms.TextBox();
            this.txtYapilanIslem = new System.Windows.Forms.TextBox();
            this.txtMiktar = new System.Windows.Forms.NumericUpDown();
            this.txtBirimFiyat = new System.Windows.Forms.TextBox();
            this.btnEkle = new System.Windows.Forms.Button();
            this.dgvIslemler = new System.Windows.Forms.DataGridView();
            this.btnYeni = new System.Windows.Forms.Button();
            this.btnSecSil = new System.Windows.Forms.Button();
            this.btnTaburcu = new System.Windows.Forms.Button();
            this.btnYazdir = new System.Windows.Forms.Button();
            this.btnBaskiOnizleme = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.lblToplamTutar = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.txtMiktar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIslemler)).BeginInit();
            this.SuspendLayout();
            // 
            // lblDosyaNo
            // 
            this.lblDosyaNo.Location = new System.Drawing.Point(20, 20);
            this.lblDosyaNo.Name = "lblDosyaNo";
            this.lblDosyaNo.Size = new System.Drawing.Size(100, 23);
            this.lblDosyaNo.TabIndex = 0;
            this.lblDosyaNo.Text = "Dosya No:";
            // 
            // txtDosyaNo
            // 
            this.txtDosyaNo.Location = new System.Drawing.Point(120, 20);
            this.txtDosyaNo.Name = "txtDosyaNo";
            this.txtDosyaNo.Size = new System.Drawing.Size(100, 22);
            this.txtDosyaNo.TabIndex = 1;
            // 
            // btnBul
            // 
            this.btnBul.Location = new System.Drawing.Point(240, 20);
            this.btnBul.Name = "btnBul";
            this.btnBul.Size = new System.Drawing.Size(75, 23);
            this.btnBul.TabIndex = 2;
            this.btnBul.Text = "Bul";
            // 
            // lblSevkTarihi
            // 
            this.lblSevkTarihi.Location = new System.Drawing.Point(20, 60);
            this.lblSevkTarihi.Name = "lblSevkTarihi";
            this.lblSevkTarihi.Size = new System.Drawing.Size(100, 23);
            this.lblSevkTarihi.TabIndex = 3;
            this.lblSevkTarihi.Text = "Sevk Tarihi:";
            // 
            // dtpSevkTarihi
            // 
            this.dtpSevkTarihi.Location = new System.Drawing.Point(120, 60);
            this.dtpSevkTarihi.Name = "dtpSevkTarihi";
            this.dtpSevkTarihi.Size = new System.Drawing.Size(200, 22);
            this.dtpSevkTarihi.TabIndex = 4;
            // 
            // lblHastaAdi
            // 
            this.lblHastaAdi.Location = new System.Drawing.Point(20, 100);
            this.lblHastaAdi.Name = "lblHastaAdi";
            this.lblHastaAdi.Size = new System.Drawing.Size(100, 23);
            this.lblHastaAdi.TabIndex = 5;
            this.lblHastaAdi.Text = "Hasta Adı:";
            // 
            // txtHastaAdi
            // 
            this.txtHastaAdi.Location = new System.Drawing.Point(120, 100);
            this.txtHastaAdi.Name = "txtHastaAdi";
            this.txtHastaAdi.Size = new System.Drawing.Size(100, 22);
            this.txtHastaAdi.TabIndex = 6;
            // 
            // lblSoyadi
            // 
            this.lblSoyadi.Location = new System.Drawing.Point(20, 140);
            this.lblSoyadi.Name = "lblSoyadi";
            this.lblSoyadi.Size = new System.Drawing.Size(100, 23);
            this.lblSoyadi.TabIndex = 7;
            this.lblSoyadi.Text = "Soyadı:";
            // 
            // txtSoyadi
            // 
            this.txtSoyadi.Location = new System.Drawing.Point(120, 140);
            this.txtSoyadi.Name = "txtSoyadi";
            this.txtSoyadi.Size = new System.Drawing.Size(100, 22);
            this.txtSoyadi.TabIndex = 8;
            // 
            // lblKurumAdi
            // 
            this.lblKurumAdi.Location = new System.Drawing.Point(20, 180);
            this.lblKurumAdi.Name = "lblKurumAdi";
            this.lblKurumAdi.Size = new System.Drawing.Size(100, 23);
            this.lblKurumAdi.TabIndex = 9;
            this.lblKurumAdi.Text = "Kurum Adı:";
            // 
            // txtKurumAdi
            // 
            this.txtKurumAdi.Location = new System.Drawing.Point(120, 180);
            this.txtKurumAdi.Name = "txtKurumAdi";
            this.txtKurumAdi.Size = new System.Drawing.Size(100, 22);
            this.txtKurumAdi.TabIndex = 10;
            // 
            // btnHastaBilgileri
            // 
            this.btnHastaBilgileri.Location = new System.Drawing.Point(240, 180);
            this.btnHastaBilgileri.Name = "btnHastaBilgileri";
            this.btnHastaBilgileri.Size = new System.Drawing.Size(115, 23);
            this.btnHastaBilgileri.TabIndex = 11;
            this.btnHastaBilgileri.Text = "Hasta Bilgileri";
            // 
            // cbPoliklinik
            // 
            this.cbPoliklinik.Location = new System.Drawing.Point(20, 220);
            this.cbPoliklinik.Name = "cbPoliklinik";
            this.cbPoliklinik.Size = new System.Drawing.Size(121, 24);
            this.cbPoliklinik.TabIndex = 12;
            // 
            // txtSiraNo
            // 
            this.txtSiraNo.Location = new System.Drawing.Point(160, 220);
            this.txtSiraNo.Name = "txtSiraNo";
            this.txtSiraNo.Size = new System.Drawing.Size(100, 22);
            this.txtSiraNo.TabIndex = 13;
            // 
            // txtYapilanIslem
            // 
            this.txtYapilanIslem.Location = new System.Drawing.Point(300, 220);
            this.txtYapilanIslem.Name = "txtYapilanIslem";
            this.txtYapilanIslem.Size = new System.Drawing.Size(100, 22);
            this.txtYapilanIslem.TabIndex = 14;
            // 
            // txtMiktar
            // 
            this.txtMiktar.Location = new System.Drawing.Point(540, 220);
            this.txtMiktar.Name = "txtMiktar";
            this.txtMiktar.Size = new System.Drawing.Size(100, 22);
            this.txtMiktar.TabIndex = 16;
            // 
            // txtBirimFiyat
            // 
            this.txtBirimFiyat.Location = new System.Drawing.Point(660, 220);
            this.txtBirimFiyat.Name = "txtBirimFiyat";
            this.txtBirimFiyat.Size = new System.Drawing.Size(100, 22);
            this.txtBirimFiyat.TabIndex = 17;
            // 
            // btnEkle
            // 
            this.btnEkle.Location = new System.Drawing.Point(780, 220);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(75, 23);
            this.btnEkle.TabIndex = 18;
            this.btnEkle.Text = "Ekle";
           
            // 
            // dgvIslemler
            // 
            this.dgvIslemler.Location = new System.Drawing.Point(20, 260);
            this.dgvIslemler.Name = "dgvIslemler";
            this.dgvIslemler.Size = new System.Drawing.Size(880, 200);
            this.dgvIslemler.TabIndex = 19;
            // 
            // btnYeni
            // 
            this.btnYeni.Location = new System.Drawing.Point(20, 480);
            this.btnYeni.Name = "btnYeni";
            this.btnYeni.Size = new System.Drawing.Size(75, 23);
            this.btnYeni.TabIndex = 20;
            this.btnYeni.Text = "Yeni";
            
            // 
            // btnSecSil
            // 
            this.btnSecSil.Location = new System.Drawing.Point(120, 480);
            this.btnSecSil.Name = "btnSecSil";
            this.btnSecSil.Size = new System.Drawing.Size(75, 23);
            this.btnSecSil.TabIndex = 21;
            this.btnSecSil.Text = "Seç - Sil";
            
            // 
            // btnTaburcu
            // 
            this.btnTaburcu.Location = new System.Drawing.Point(220, 480);
            this.btnTaburcu.Name = "btnTaburcu";
            this.btnTaburcu.Size = new System.Drawing.Size(75, 23);
            this.btnTaburcu.TabIndex = 22;
            this.btnTaburcu.Text = "Taburcu";
            // 
            // btnYazdir
            // 
            this.btnYazdir.Location = new System.Drawing.Point(320, 480);
            this.btnYazdir.Name = "btnYazdir";
            this.btnYazdir.Size = new System.Drawing.Size(75, 23);
            this.btnYazdir.TabIndex = 23;
            this.btnYazdir.Text = "Yazdır";
            // 
            // btnBaskiOnizleme
            // 
            this.btnBaskiOnizleme.Location = new System.Drawing.Point(420, 480);
            this.btnBaskiOnizleme.Name = "btnBaskiOnizleme";
            this.btnBaskiOnizleme.Size = new System.Drawing.Size(119, 23);
            this.btnBaskiOnizleme.TabIndex = 24;
            this.btnBaskiOnizleme.Text = "Baskı Önizleme";
            // 
            // btnCikis
            // 
            this.btnCikis.Location = new System.Drawing.Point(560, 480);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(75, 23);
            this.btnCikis.TabIndex = 25;
            this.btnCikis.Text = "Çıkış";
            // 
            // lblToplamTutar
            // 
            this.lblToplamTutar.Location = new System.Drawing.Point(20, 520);
            this.lblToplamTutar.Name = "lblToplamTutar";
            this.lblToplamTutar.Size = new System.Drawing.Size(200, 23);
            this.lblToplamTutar.TabIndex = 26;
            this.lblToplamTutar.Text = "Toplam Tutar: 0 YTL";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 201);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 16);
            this.label1.TabIndex = 27;
            this.label1.Text = "POLİKİNLİK";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(159, 201);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 16);
            this.label2.TabIndex = 28;
            this.label2.Text = "SIRA NO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(317, 201);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 29;
            this.label3.Text = "Yapılan İşlem";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(439, 201);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 30;
            this.label4.Text = "Dr.Kodu";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(592, 201);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 16);
            this.label5.TabIndex = 31;
            this.label5.Text = "Miktar";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(676, 201);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 16);
            this.label6.TabIndex = 32;
            this.label6.Text = "Birim Fiyat";
            // 
            // comboBox1
            // 
            this.comboBox1.Location = new System.Drawing.Point(420, 220);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(107, 24);
            this.comboBox1.TabIndex = 33;
            // 
            // HastaIslemleriForm
            // 
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(920, 560);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblDosyaNo);
            this.Controls.Add(this.txtDosyaNo);
            this.Controls.Add(this.btnBul);
            this.Controls.Add(this.lblSevkTarihi);
            this.Controls.Add(this.dtpSevkTarihi);
            this.Controls.Add(this.lblHastaAdi);
            this.Controls.Add(this.txtHastaAdi);
            this.Controls.Add(this.lblSoyadi);
            this.Controls.Add(this.txtSoyadi);
            this.Controls.Add(this.lblKurumAdi);
            this.Controls.Add(this.txtKurumAdi);
            this.Controls.Add(this.btnHastaBilgileri);
            this.Controls.Add(this.cbPoliklinik);
            this.Controls.Add(this.txtSiraNo);
            this.Controls.Add(this.txtYapilanIslem);
            this.Controls.Add(this.txtMiktar);
            this.Controls.Add(this.txtBirimFiyat);
            this.Controls.Add(this.btnEkle);
            this.Controls.Add(this.dgvIslemler);
            this.Controls.Add(this.btnYeni);
            this.Controls.Add(this.btnSecSil);
            this.Controls.Add(this.btnTaburcu);
            this.Controls.Add(this.btnYazdir);
            this.Controls.Add(this.btnBaskiOnizleme);
            this.Controls.Add(this.btnCikis);
            this.Controls.Add(this.lblToplamTutar);
            this.Name = "HastaIslemleriForm";
            this.Text = "Hasta İşlemleri";
            
            ((System.ComponentModel.ISupportInitialize)(this.txtMiktar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIslemler)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label lblDosyaNo;
        private System.Windows.Forms.TextBox txtDosyaNo;
        private System.Windows.Forms.Button btnBul;
        private System.Windows.Forms.Label lblSevkTarihi;
        private System.Windows.Forms.DateTimePicker dtpSevkTarihi;
        private System.Windows.Forms.Label lblHastaAdi;
        private System.Windows.Forms.TextBox txtHastaAdi;
        private System.Windows.Forms.Label lblSoyadi;
        private System.Windows.Forms.TextBox txtSoyadi;
        private System.Windows.Forms.Label lblKurumAdi;
        private System.Windows.Forms.TextBox txtKurumAdi;
        private System.Windows.Forms.Button btnHastaBilgileri;
        private System.Windows.Forms.ComboBox cbPoliklinik;
        private System.Windows.Forms.TextBox txtSiraNo;
        private System.Windows.Forms.TextBox txtYapilanIslem;
        private System.Windows.Forms.NumericUpDown txtMiktar;
        private System.Windows.Forms.TextBox txtBirimFiyat;
        private System.Windows.Forms.Button btnEkle;
        private System.Windows.Forms.DataGridView dgvIslemler;
        private System.Windows.Forms.Button btnYeni;
        private System.Windows.Forms.Button btnSecSil;
        private System.Windows.Forms.Button btnTaburcu;
        private System.Windows.Forms.Button btnYazdir;
        private System.Windows.Forms.Button btnBaskiOnizleme;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.Label lblToplamTutar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}