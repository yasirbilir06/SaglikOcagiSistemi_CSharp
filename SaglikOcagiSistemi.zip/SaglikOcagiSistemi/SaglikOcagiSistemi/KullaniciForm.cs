﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace SaglikOcagiSistemi
{
    public partial class KullaniciForm : Form
    {
        public KullaniciForm()
        {
            InitializeComponent();
        }

        // Form yüklendiğinde çalışacak metod
        private void KullaniciForm_Load(object sender, EventArgs e)
        {
            LoadKullaniciKodu();
        }

        // ComboBox'a veritabanından kullanıcı kodlarını yükleyen metod
        private void LoadKullaniciKodu()
        {
            string connectionString = "Server=FURKAN\\SQLEXPRESS;Database=SaglikOcagi;Trusted_Connection=True;";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT Kodu FROM Kullanici";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            cmbKullaniciKodu.Items.Clear(); // Önce listeyi temizle
                            while (reader.Read())
                            {
                                cmbKullaniciKodu.Items.Add(reader["Kodu"].ToString());
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Kullanıcı kodları yüklenirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Yeni kullanıcı ekle butonu
        private void BtnYeniKullaniciEkle_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Yeni kullanıcı ekleme işlemi başlatıldı.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            // Buraya yeni kullanıcı ekleme formu açılabilir.
        }

        // ComboBox'tan kullanıcı seçildiğinde çalışacak metod
        private void cmbKullaniciKodu_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedKullaniciKodu = cmbKullaniciKodu.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(selectedKullaniciKodu))
            {
                try
                {
                    KullaniciTanıtmaForm kullaniciTanıtmaForm = new KullaniciTanıtmaForm(selectedKullaniciKodu);
                    kullaniciTanıtmaForm.ShowDialog();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Kullanıcı tanıtma formu açılırken bir hata oluştu: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}