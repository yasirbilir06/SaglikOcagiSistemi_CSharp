﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SaglikOcagiSistemi
{
    public partial class KullaniciTanıtmaForm : Form
    {
        private string SelectedKullaniciKodu;

        public KullaniciTanıtmaForm(string kullaniciKodu)
        {
            InitializeComponent();
            SelectedKullaniciKodu = kullaniciKodu;
            LoadKullaniciDetails();
        }

        private void LoadKullaniciDetails()
        {
            string connectionString = "Server=FURKAN\\SQLEXPRESS;Database=SaglikOcagi;Trusted_Connection=True;";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM Kullanici WHERE Kodu = @Kodu";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Kodu", SelectedKullaniciKodu);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                // Örneğin: Formdaki TextBox'ları doldur
                                txtKullaniciKodu.Text = reader["Kodu"].ToString();
                                txtAd.Text = reader["Ad"].ToString();
                                txtSoyad.Text = reader["Soyad"].ToString();
                                // Diğer alanları doldur
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Kullanıcı bilgileri yüklenirken bir hata oluştu: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void KullaniciTanıtmaForm_Load(object sender, EventArgs e)
        {
            // Burada form yüklenirken yapılacak işlemleri tanımlayın
            MessageBox.Show("Kullanıcı Tanıtma Formu yüklendi.");
        }
    }
}
